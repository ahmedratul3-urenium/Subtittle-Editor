export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: { extend: { colors: { navy: '#0f2747' } } },
  plugins: []
};
