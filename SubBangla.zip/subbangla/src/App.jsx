import React, { useState, useRef, useEffect, useMemo, memo } from 'react';
import { parse, build, fmt, toMs, uid } from './lib/srt.js';
import { saveFile } from './lib/save.js';

const KEY = 'subbangla:v1';
const FONTS = { Kalpurush: "'Kalpurush','Noto Sans Bengali',sans-serif", Nikosh: "'Nikosh','Noto Sans Bengali',sans-serif", Noto: "'Noto Sans Bengali',sans-serif" };
const load = () => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch { return {}; } };

const B = 'h-10 rounded-lg px-3 text-sm font-semibold active:scale-95 disabled:opacity-40 ';
const BN = B + 'bg-navy text-white';
const BG = B + 'bg-green-700 text-white';
const BL = B + 'bg-slate-200 text-slate-800';

function splitText(t) {
  if (!t) return ['', ''];
  const nl = t.indexOf('\n');
  if (nl > 0) return [t.slice(0, nl), t.slice(nl + 1)];
  const mid = t.length / 2;
  let best = -1;
  for (let i = 0; i < t.length; i++) if (t[i] === ' ' && (best < 0 || Math.abs(i - mid) < Math.abs(best - mid))) best = i;
  return best < 0 ? [t, ''] : [t.slice(0, best), t.slice(best + 1)];
}

function FileBtn({ accept, onChange, children, cls }) {
  return (
    <label className={'flex cursor-pointer items-center justify-center ' + cls}>
      {children}
      <input type="file" accept={accept} onChange={onChange} className="hidden" />
    </label>
  );
}

function Clock({ vref }) {
  const [t, setT] = useState(0);
  useEffect(() => {
    const id = setInterval(() => { const v = vref.current; if (v) setT(Math.floor(v.currentTime * 10)); }, 250);
    return () => clearInterval(id);
  }, [vref]);
  return <span className="font-mono text-xs text-slate-700">{fmt(t * 100, '.')}</span>;
}

function TimeInput({ ms, onCommit }) {
  const [v, setV] = useState(fmt(ms));
  useEffect(() => setV(fmt(ms)), [ms]);
  const done = () => { const n = toMs(v); if (isNaN(n)) setV(fmt(ms)); else if (n !== ms) onCommit(n); };
  return (
    <input value={v} onChange={(e) => setV(e.target.value)} onBlur={done}
      onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.blur()}
      className="h-9 w-[7.4rem] rounded-lg border border-slate-300 px-2 font-mono text-xs" />
  );
}

const Row = memo(function Row({ s, i, active, font, a }) {
  return (
    <div id={'r' + i} className={'rounded-xl border bg-white p-3 shadow-sm ' + (active ? 'border-green-600 ring-2 ring-green-600/30' : 'border-slate-200')}>
      <div className="flex flex-wrap items-center gap-2">
        <button onClick={() => a.seek(s.start)} className="h-9 min-w-[2.25rem] rounded-lg bg-navy px-2 text-sm font-bold text-white" aria-label="এই সাবটাইটেলে যান">{i + 1}</button>
        <TimeInput ms={s.start} onCommit={(v) => a.time(s.id, { start: v })} />
        <span className="text-slate-400">→</span>
        <TimeInput ms={s.end} onCommit={(v) => a.time(s.id, { end: v })} />
      </div>
      <div className="mt-2 grid gap-2 sm:grid-cols-2">
        <p className="whitespace-pre-wrap break-words rounded-lg bg-slate-100 p-2 text-sm text-slate-700">{s.en}</p>
        <textarea value={s.bn} onFocus={a.snap} onChange={(e) => a.upd(s.id, { bn: e.target.value })}
          rows={Math.max(2, s.en.split('\n').length)} placeholder="বাংলা অনুবাদ লিখুন"
          style={{ fontFamily: font }}
          className="w-full rounded-lg border border-slate-300 p-2 text-base focus:border-green-600 focus:outline-none" />
      </div>
      <div className="mt-2 flex flex-wrap gap-2">
        <button className={BL} onClick={() => a.add(i)}>নিচে যোগ</button>
        <button className={BL} onClick={() => a.split(i)}>ভাগ</button>
        <button className={BL} onClick={() => a.merge(i)}>পরেরটার সাথে যুক্ত</button>
        <button className={B + 'bg-red-100 text-red-700'} onClick={() => a.del(s.id)}>মুছুন</button>
      </div>
    </div>
  );
});

export default function App() {
  const saved = useMemo(load, []);
  const [subs, setSubs] = useState(saved.subs || []);
  const [name, setName] = useState(saved.name || '');
  const [video, setVideo] = useState(null);
  const [cur, setCur] = useState(-1);
  const [q, setQ] = useState('');
  const [shift, setShift] = useState('0.5');
  const [fontKey, setFontKey] = useState('Kalpurush');
  const [fs, setFs] = useState(20);
  const [showVideo, setShowVideo] = useState(true);
  const [msg, setMsg] = useState('');
  const vref = useRef(null), wrap = useRef(null), subsRef = useRef(subs), past = useRef([]), future = useRef([]), tmo = useRef(0);
  subsRef.current = subs;
  const font = FONTS[fontKey];

  const say = (m) => { setMsg(m); clearTimeout(tmo.current); tmo.current = setTimeout(() => setMsg(''), 3500); };

  const a = useMemo(() => {
    const snap = () => { past.current.push(subsRef.current); if (past.current.length > 100) past.current.shift(); future.current = []; };
    const upd = (id, p) => setSubs((l) => l.map((x) => (x.id === id ? { ...x, ...p } : x)));
    return {
      snap, upd,
      time: (id, p) => { snap(); upd(id, p); },
      seek: (ms) => { const v = vref.current; if (v) v.currentTime = ms / 1000 + 0.001; },
      add: (i) => { snap(); setSubs((l) => { const s = l[i]; return [...l.slice(0, i + 1), { id: uid(), start: s.end, end: s.end + 2000, en: '', bn: '' }, ...l.slice(i + 1)]; }); },
      del: (id) => { snap(); setSubs((l) => l.filter((x) => x.id !== id)); },
      merge: (i) => {
        const l = subsRef.current;
        if (i >= l.length - 1) return say('পরের সাবটাইটেল নেই');
        snap();
        const x = l[i], y = l[i + 1];
        const j = (p, r) => [p, r].filter(Boolean).join('\n');
        setSubs([...l.slice(0, i), { ...x, end: Math.max(x.end, y.end), en: j(x.en, y.en), bn: j(x.bn, y.bn) }, ...l.slice(i + 2)]);
      },
      split: (i) => {
        const l = subsRef.current, x = l[i];
        snap();
        const mid = Math.round((x.start + x.end) / 2);
        const [e1, e2] = splitText(x.en), [b1, b2] = splitText(x.bn);
        setSubs([...l.slice(0, i), { ...x, end: mid, en: e1, bn: b1 }, { id: uid(), start: mid, end: x.end, en: e2, bn: b2 }, ...l.slice(i + 1)]);
      }
    };
  }, []);

  // Auto-save
  useEffect(() => {
    const t = setTimeout(() => {
      try { localStorage.setItem(KEY, JSON.stringify({ subs, name })); } catch { say('সংরক্ষণ ব্যর্থ: ডিভাইসে জায়গা কম'); }
    }, 600);
    return () => clearTimeout(t);
  }, [subs, name]);

  // Track the playing subtitle frame-accurately
  useEffect(() => {
    let last = -2;
    const id = setInterval(() => {
      const v = vref.current;
      if (v) {
        const t = v.currentTime * 1000, l = subsRef.current;
        const k = last >= 0 && l[last] && t >= l[last].start && t < l[last].end ? last : l.findIndex((s) => t >= s.start && t < s.end);
        if (k !== last) { last = k; setCur(k); }
      }
    }, 120);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const v = vref.current;
    if (cur >= 0 && v && !v.paused) document.getElementById('r' + cur)?.scrollIntoView({ block: 'nearest', behavior: 'auto' });
  }, [cur]);

  const onVid = (e) => {
    const f = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!f) return;
    if (video) URL.revokeObjectURL(video.url);
    setVideo({ url: URL.createObjectURL(f), name: f.name });
  };

  const onSub = async (e) => {
    const f = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!f) return;
    try {
      const list = parse(await f.text());
      if (!list.length) return say('বৈধ সাবটাইটেল পাওয়া যায়নি। .srt বা .vtt ফাইল বেছে নিন।');
      if (subs.length && !window.confirm('বর্তমান সাবটাইটেল ও অনুবাদ বদলে যাবে। চালিয়ে যাবেন?')) return;
      a.snap();
      setSubs(list);
      setName(f.name);
      say(list.length + 'টি সাবটাইটেল লোড হয়েছে');
    } catch { say('ফাইল পড়া যায়নি'); }
  };

  const undo = () => { const p = past.current.pop(); if (!p) return; future.current.push(subs); setSubs(p); };
  const redo = () => { const f = future.current.pop(); if (!f) return; past.current.push(subs); setSubs(f); };

  const addAtTime = () => {
    const t = Math.round(((vref.current && vref.current.currentTime) || 0) * 1000);
    a.snap();
    setSubs((l) => {
      const n = { id: uid(), start: t, end: t + 2000, en: '', bn: '' };
      const k = l.findIndex((s) => s.start > t);
      return k < 0 ? [...l, n] : [...l.slice(0, k), n, ...l.slice(k)];
    });
  };

  const doShift = (dir) => {
    const d = Math.round(parseFloat(shift) * 1000) * dir;
    if (!d) return say('সেকেন্ড সংখ্যা লিখুন (যেমন 0.5)');
    a.snap();
    setSubs((l) => l.map((s) => ({ ...s, start: Math.max(0, s.start + d), end: Math.max(0, s.end + d) })));
  };

  const exp = async (mode, vtt) => {
    if (!subs.length) return say('আগে সাবটাইটেল যোগ করুন');
    const base = (name || 'subtitle').replace(/\.[^.]+$/, '');
    const file = base + (mode === 'dual' ? '.en-bn' : '.bn') + (vtt ? '.vtt' : '.srt');
    try { await saveFile(file, build(subs, mode, vtt), vtt ? 'text/vtt' : 'application/x-subrip'); say('এক্সপোর্ট সম্পন্ন: ' + file); }
    catch (e) { say('এক্সপোর্ট ব্যর্থ: ' + ((e && e.message) || e)); }
  };

  const clearAll = () => {
    if (!window.confirm('সব সাবটাইটেল ও অনুবাদ মুছে যাবে। নিশ্চিত?')) return;
    a.snap(); setSubs([]); setName(''); localStorage.removeItem(KEY);
  };

  const fullscreen = () => {
    try { document.fullscreenElement ? document.exitFullscreen() : wrap.current.requestFullscreen(); }
    catch { say('ফুলস্ক্রিন চালু করা যায়নি'); }
  };
  const vStep = (d) => { const v = vref.current; if (v) v.currentTime = Math.max(0, v.currentTime + d); };

  const needle = q.trim().toLowerCase();
  const rows = subs.map((s, i) => [s, i]).filter(([s]) => !needle || s.en.toLowerCase().includes(needle) || s.bn.toLowerCase().includes(needle));
  const done = subs.filter((s) => s.bn.trim()).length;
  const curSub = cur >= 0 ? subs[cur] : null;

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900">
      <header className="flex items-center gap-2 bg-navy px-3 pb-2 pt-[max(0.5rem,env(safe-area-inset-top))] text-white">
        <h1 className="mr-auto text-lg font-bold">Sub<span className="text-green-400">Bangla</span></h1>
        <FileBtn accept="video/*" onChange={onVid} cls={BG}>ভিডিও</FileBtn>
        <FileBtn accept="*/*" onChange={onSub} cls={BG}>ইংরেজি SRT</FileBtn>
      </header>

      <main className="gap-3 p-2 landscape:grid landscape:grid-cols-2">
        <section className="sticky top-0 z-20 bg-slate-100 pb-2 landscape:top-2 landscape:self-start">
          <div ref={wrap} className={'relative overflow-hidden rounded-xl bg-black ' + (showVideo ? '' : 'hidden')}>
            {video ? (
              <video ref={vref} src={video.url} controls playsInline preload="metadata" disablePictureInPicture disableRemotePlayback controlsList="nofullscreen"
                onError={() => say('এই ভিডিও ফরম্যাট ডিভাইসে চালানো যাচ্ছে না। MP4 (H.264) ব্যবহার করুন।')}
                className="mx-auto max-h-[34vh] w-full landscape:max-h-[62vh]" />
            ) : (
              <div className="flex h-36 items-center justify-center px-4 text-center text-sm text-slate-300">ওপরের “ভিডিও” বোতামে চেপে ফোন থেকে ভিডিও বেছে নিন</div>
            )}
            {curSub && (curSub.bn || curSub.en) && (
              <div className="pointer-events-none absolute inset-x-0 bottom-14 px-3 text-center">
                <span className="inline-block whitespace-pre-line px-2 font-semibold text-white" style={{ fontFamily: font, fontSize: fs, textShadow: '0 0 3px #000, 0 0 3px #000, 1px 1px 2px #000' }}>{curSub.bn || curSub.en}</span>
              </div>
            )}
          </div>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <button className={BN} onClick={() => vStep(-10)}>−10s</button>
            <button className={BN} onClick={() => vStep(10)}>+10s</button>
            <select className={BL} defaultValue="1" onChange={(e) => { if (vref.current) vref.current.playbackRate = +e.target.value; }} aria-label="গতি">
              {[0.5, 0.75, 1, 1.25, 1.5, 2].map((r) => <option key={r} value={r}>{r}x</option>)}
            </select>
            <button className={BL} onClick={() => setFs((x) => Math.max(12, x - 2))}>A−</button>
            <button className={BL} onClick={() => setFs((x) => Math.min(40, x + 2))}>A+</button>
            <select className={BL} value={fontKey} onChange={(e) => setFontKey(e.target.value)} aria-label="ফন্ট">
              {Object.keys(FONTS).map((k) => <option key={k}>{k}</option>)}
            </select>
            <button className={BL} onClick={fullscreen}>ফুলস্ক্রিন</button>
            <button className={BL} onClick={() => setShowVideo((x) => !x)}>{showVideo ? 'ভিডিও লুকান' : 'ভিডিও দেখান'}</button>
            <Clock vref={vref} />
          </div>
        </section>

        <section className="min-w-0">
          <div className="rounded-xl bg-white p-3 shadow-sm">
            <div className="flex flex-wrap items-center gap-2">
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="সাবটাইটেল খুঁজুন" className="h-10 min-w-0 flex-1 rounded-lg border border-slate-300 px-3 text-sm" />
              <button className={BL} onClick={undo}>আনডু</button>
              <button className={BL} onClick={redo}>রিডু</button>
              <button className={BN} onClick={addAtTime}>+ নতুন</button>
            </div>
            <div className="mt-2 flex flex-wrap items-center gap-2 text-sm">
              <span>সময় সরান:</span>
              <input value={shift} onChange={(e) => setShift(e.target.value)} inputMode="decimal" className="h-10 w-16 rounded-lg border border-slate-300 px-2 text-center" />
              <span>সেকেন্ড</span>
              <button className={BL} onClick={() => doShift(-1)}>আগে</button>
              <button className={BL} onClick={() => doShift(1)}>পরে</button>
            </div>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <button className={BG} onClick={() => exp('bn', false)}>বাংলা SRT</button>
              <button className={BG} onClick={() => exp('dual', false)}>দ্বিভাষিক SRT</button>
              <button className={BG} onClick={() => exp('bn', true)}>VTT</button>
              <button className={B + 'ml-auto bg-red-100 text-red-700'} onClick={clearAll}>সব মুছুন</button>
            </div>
            <p className="mt-2 text-xs text-slate-500">{subs.length ? `${done}/${subs.length} অনুবাদিত · স্বয়ংক্রিয়ভাবে সংরক্ষিত${name ? ' · ' + name : ''}` : 'ফোনেই সংরক্ষিত থাকে, ইন্টারনেট লাগে না।'}</p>
          </div>

          <div className="mt-2 space-y-2 pb-24">
            {!subs.length && (
              <div className="rounded-xl border-2 border-dashed border-slate-300 p-6 text-center text-sm text-slate-600">
                শুরু করতে “ইংরেজি SRT” বোতামে চেপে .srt বা .vtt ফাইল বেছে নিন।
              </div>
            )}
            {subs.length > 0 && !rows.length && <p className="p-4 text-center text-sm text-slate-500">কিছু পাওয়া যায়নি</p>}
            {rows.map(([s, i]) => <Row key={s.id} s={s} i={i} active={i === cur} font={font} a={a} />)}
          </div>
        </section>
      </main>

      {msg && <div className="fixed inset-x-3 bottom-[max(1rem,env(safe-area-inset-bottom))] z-40 rounded-xl bg-navy px-4 py-3 text-center text-sm text-white shadow-lg">{msg}</div>}
    </div>
  );
}
