const p2 = (n, l = 2) => String(n).padStart(l, '0');

// "hh:mm:ss,mmm" বা "mm:ss.mmm" -> সেকেন্ড; ভুল হলে NaN
export function tc(str) {
  const m = String(str).trim().match(/^(?:(\d+):)?(\d+):(\d+)[,.](\d{1,3})$/);
  if (!m) return NaN;
  return Number(m[1] || 0) * 3600 + Number(m[2]) * 60 + Number(m[3]) + Number(m[4].padEnd(3, '0')) / 1000;
}

export function fmt(t, sep = ',') {
  const ms = Math.round(Math.max(0, t) * 1000);
  return `${p2(Math.floor(ms / 3600000))}:${p2(Math.floor(ms / 60000) % 60)}:${p2(Math.floor(ms / 1000) % 60)}${sep}${p2(ms % 1000, 3)}`;
}

export function parse(text) {
  const blocks = text.replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n').split(/\n{2,}/);
  const out = [];
  blocks.forEach((b, k) => {
    const lines = b.split('\n');
    const i = lines.findIndex(l => l.includes('-->'));
    if (i < 0) return;
    const [a, c] = lines[i].split('-->');
    const s = tc(a), e = tc(c.trim().split(/\s+/)[0]);
    if (isNaN(s) || isNaN(e)) return;
    const en = lines.slice(i + 1).join('\n').replace(/<[^>]+>/g, '').trim();
    out.push({ id: Date.now() + k, s, e, en, bn: '' });
  });
  return out;
}

const body = (subs, mode, sep) =>
  subs.map((x, i) => {
    const t = mode === 'dual' ? [x.en, x.bn].filter(Boolean).join('\n') : (x.bn || x.en);
    return `${i + 1}\n${fmt(x.s, sep)} --> ${fmt(x.e, sep)}\n${t}\n`;
  }).join('\n');

export const toSrt = (subs, mode = 'bn') => body(subs, mode, ',');
export const toVtt = subs => 'WEBVTT\n\n' + body(subs, 'bn', '.');
