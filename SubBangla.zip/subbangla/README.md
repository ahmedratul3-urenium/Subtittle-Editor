# SubBangla

ইংরেজি সাবটাইটেল (SRT/VTT) → বাংলা সম্পাদনা অ্যাপ। React + Vite + Tailwind + Capacitor Android।

## প্রয়োজন
Node.js 18+, JDK 17, Android Studio (Android SDK)।

## ওয়েব
```
npm install
npm run dev      # ডেভেলপমেন্ট
npm run build    # dist/ তৈরি
```

## Android APK
```
npm install
npm run cap:add                  # প্রথমবার: android/ ফোল্ডার তৈরি
npm run assets                   # আইকন ও স্প্লাশ (assets/ থেকে)
npm run apk:debug                # android/app/build/outputs/apk/debug/app-debug.apk
```
ফোনে `app-debug.apk` কপি করে ইনস্টল করুন (Unknown sources অনুমতি দিন)।

### Release APK
```
keytool -genkey -v -keystore subbangla.keystore -alias subbangla -keyalg RSA -keysize 2048 -validity 10000
npm run apk:release
cd android/app/build/outputs/apk/release
zipalign -v -p 4 app-release-unsigned.apk aligned.apk
apksigner sign --ks ../../../../../../subbangla.keystore --out SubBangla.apk aligned.apk
```
keystore ফাইল ও পাসওয়ার্ড নিরাপদে রাখুন; হারালে আপডেট দেওয়া যাবে না।

### অনুমতি ও ওরিয়েন্টেশন
ফাইল বাছাই Android-এর সিস্টেম পিকার (Storage Access Framework) দিয়ে হয়, তাই আলাদা storage permission লাগে না। Portrait ও landscape দুটোই চলে (Capacitor-এর ডিফল্ট `configChanges`)।

## Netlify
GitHub-এ পুশ করে Netlify-তে রিপো যুক্ত করুন। `netlify.toml` অনুযায়ী বিল্ড ও পাবলিশ হবে।

## বাংলা ফন্ট
`Kalpurush.ttf` ও `Nikosh.ttf` ফাইল `public/fonts/` ফোল্ডারে রাখুন (লাইসেন্স মেনে)। না থাকলে Noto Sans Bengali ব্যবহৃত হয়।

## এক্সপোর্ট
Android-এ এক্সপোর্টে শেয়ার শিট খোলে — "Files"/"Drive" বেছে সংরক্ষণ করুন। ফাইল UTF-8 এনকোডিংয়ে সংরক্ষিত হয়।

## সীমাবদ্ধতা (v1)
AI অনুবাদ, টেক্সট ফরম্যাটিং টুলবার (Bold/Italic/Color) এখনো নেই।
