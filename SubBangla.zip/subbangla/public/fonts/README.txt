Kalpurush.ttf এবং Nikosh.ttf এখানে রাখুন (বৈধ লাইসেন্সসহ ডাউনলোড করা ফাইল)।
না থাকলে ডিভাইসের Noto Sans Bengali ব্যবহার হবে।
